/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.luciano.crud.biblioteca.DAO;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.luciano.crud.biblioteca.entidades.ItemBiblioteca;
import com.luciano.crud.biblioteca.entidades.Tipo;
import com.luciano.crud.biblioteca.filtros.ItemFiltro;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Luciano Azevedo
 */
public class ItemBibliotecaDAO {

    // cria um mapa de iptens de biblioteca para servir de DB
    private static Map<Integer, ItemBiblioteca> REPOSITORY = new ConcurrentHashMap<Integer, ItemBiblioteca>(new HashMap<Integer, ItemBiblioteca>());

    // autonumeração para ID (contador)
    private static AtomicInteger ID = new AtomicInteger();

    public void save(ItemBiblioteca item) throws PersistenciaException {
        item.setId(ID.getAndIncrement());
        REPOSITORY.put(item.getId(), item);
    }

    public void update(ItemBiblioteca item) throws PersistenciaException {
        REPOSITORY.put(item.getId(), item);
    }

    public void delete(ItemBiblioteca item) throws PersistenciaException {
        REPOSITORY.remove(item.getId());
    }

    public ItemBiblioteca getByID(int itemId) throws PersistenciaException {
        return REPOSITORY.get(itemId);
    }

    public List<ItemBiblioteca> getAll() throws PersistenciaException {
        return new ArrayList<ItemBiblioteca>(REPOSITORY.values());
    }

    public List<ItemBiblioteca> findBy(ItemFiltro filter) throws PersistenciaException {

        if (filter == null || filter.isEmpty()) {
            return new ArrayList<>(REPOSITORY.values());
        }

        List<ItemBiblioteca> resultado = new ArrayList<>();

        for (ItemBiblioteca item : REPOSITORY.values()) {

            // Tipo
            if (notEmpty(filter.getTipo())) {
                if (!equals(filter.getTipo(), item.getTipo())) {
                    continue;
                }
            }

            // Titulo
            if (notEmpty(filter.getTitulo())) {
                if (!contains(item.getTitulo(), filter.getTitulo())) {
                    continue;
                }
            }

            // Editora
            if (notEmpty(filter.getEditora())) {
                if (!contains(item.getEditora(), filter.getEditora())) {
                    continue;
                }
            }

            // Data Publicação Inicio
            if (notEmpty(filter.getDataPublicacaoInical())) {
                if (!assertDate(item.getDataPublicacao(), filter.getDataPublicacaoInical(), true)) {
                    continue;
                }
            }

            // Data Publicação Fim
            if (notEmpty(filter.getDataPublicacaoFinal())) {
                if (!assertDate(item.getDataPublicacao(), filter.getDataPublicacaoFinal(), false)) {
                    continue;
                }
            }

            //ISDN
            if (notEmpty(filter.getIsbn())) {
                if (!contains(item.getIsbn(), filter.getIsbn())) {
                    continue;
                }
            }

            // Pagina inicio
            if (notEmpty(filter.getPaginasInicial())) {
                if (!assertPagina(item.getPaginas(), filter.getPaginasInicial(), true)) {
                    continue;
                }
            }

            // Pagina Fim
            if (notEmpty(filter.getPaginasFinal())) {
                if (!assertPagina(item.getPaginas(), filter.getPaginasFinal(), false)) {
                    continue;
                }
            }

            resultado.add(item);
        }

        return resultado;

    }

    private boolean notEmpty(Object obj) {
        return obj != null;
    }

    private boolean equals(Object obj1, Object obj2) {
        return obj1.equals(obj2);
    }

    private boolean contains(String s1, String s2) {
        if (s1 == null && s2 == null) {
            return true;
        }
        if (s1 == null || s2 == null) {
            return false;
        }

        return s1.toUpperCase().contains(s2.toUpperCase());
    }

    private boolean assertDate(Date date, Date dateLimit, boolean atLeast) {
        if (date == null) {
            return true;
        }
        if (atLeast) {
            return date.compareTo(dateLimit) >= 0;
        } else {
            // atMost
            return date.compareTo(dateLimit) <= 0;
        }
    }

    private boolean assertPagina(Integer paginas, Integer paginasLimite, boolean atLeast) {
        if (paginas == null) {
            return true;
        }
        if (atLeast) {
            return paginas.compareTo(paginasLimite) >= 0;
        } else {
            return paginas.compareTo(paginasLimite) <= 0;
        }

    }

    public boolean existeIsdn(ItemBiblioteca item) {
        if (item == null) {
            return false;
        }
        for (ItemBiblioteca aItem : REPOSITORY.values()) {
            boolean isdnIgual = aItem.getIsbn().trim().equalsIgnoreCase(item.getIsbn());
            boolean mesmoIsdn = aItem.getId().equals(item.getId());
            if (isdnIgual && !mesmoIsdn) {
                return true;
            }
        }
        return false;
    }

    public void povoar() {
        ItemBiblioteca item;
        REPOSITORY.clear();
        ID.set(1);

        ArrayList<ItemBiblioteca> livros = new ArrayList<ItemBiblioteca>();

        livros.add(new ItemBiblioteca(Tipo.LIVRO, "Solutions Intermediate Student Book", "Oxford", data("10-04-2007"), "Solutions Intermediate Student Book", "9780194552883", 1199, "INGLÊS", ""));
        livros.add(new ItemBiblioteca(Tipo.CAPADURA, "Solutions Intermediate WorkBook", "Oxford", data("16-08-2007"), "Solutions Intermediate WorkBook", "9780194553674", 1096, "INGLÊS", ""));
        livros.add(new ItemBiblioteca(Tipo.PERIODICO, "Til", " L&PM", data("23-02-1997"), "Autor: José de Alencar", "9788525426192", 260, "LIVROS PARADIDÁTICOS", "Língua Portuguesa"));
        livros.add(new ItemBiblioteca(Tipo.EBOOK, "Memórias póstumas de Brás Cubas", " L&PM", data("29-06-2017"), "Autor: Machado de Assis", "8525406872", 126, "LIVROS PARADIDÁTICOS", "Língua Portuguesa"));
        livros.add(new ItemBiblioteca(Tipo.LIVRO, "Fact files - the USA Alison Baxter", "Oxford Bookworms", data("06-10-2012"), "Fact files - the USA Alison Baxter", "9780194233910", 976, "INGLÊS", ""));
        livros.add(new ItemBiblioteca(Tipo.LIVRO, "Pride And Prejudice Jane Austen", "Macmillan Readers", data("10-06-2006"), "Pride And Prejudice Jane Austen", "9781405073011", 762, "INGLÊS", ""));

        try {

            for (ItemBiblioteca livro : livros) {
                save(livro);
            }
        } catch (PersistenciaException ex) {
            Logger.getLogger(ItemBibliotecaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public Date data(String dt) {
        SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
        Date data = null;
        try {
            data = formato.parse(dt);
        } catch (ParseException ex) {

        }

        return data;
    }
}
