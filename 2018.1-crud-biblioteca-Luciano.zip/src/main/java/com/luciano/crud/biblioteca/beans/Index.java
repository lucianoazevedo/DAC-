package com.luciano.crud.biblioteca.beans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.luciano.crud.biblioteca.entidades.ItemBiblioteca;
import com.luciano.crud.biblioteca.filtros.ItemFiltro;
import com.luciano.crud.biblioteca.servicos.ItemBibliotecaServico;
import com.luciano.crud.biblioteca.servicos.ServicoException;

@RequestScoped
@ManagedBean
public class Index extends AbstractBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5976838804313515033L;

	private List<ItemBiblioteca> itens;

	private ItemBibliotecaServico itemServico = new ItemBibliotecaServico();

	private ItemFiltro itemFiltro;

	public List<ItemBiblioteca> getItens() {
		return itens;
	}

	public ItemFiltro getItemFiltro() {
		return itemFiltro;
	}

	public void setItemFiltro(ItemFiltro itemFiltro) {
		this.itemFiltro = itemFiltro;
	}

	@PostConstruct
	public void init() {
		limpar();
		filtrar();
	}

	public String filtrar() {
		try {
			itens = itemServico.findBy(getItemFiltro());
		} catch (ServicoException e) {
			reportarMensagemDeErro(e.getMessage());
			return null;
		}
		return null;
	}

	public String limpar() {
		this.itemFiltro = new ItemFiltro();
		return null;
	}

    public void povoar(){
        itemServico.povoar();
    }
}
