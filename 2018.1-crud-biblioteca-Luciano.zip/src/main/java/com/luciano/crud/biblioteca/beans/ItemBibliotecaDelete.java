package com.luciano.crud.biblioteca.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.luciano.crud.biblioteca.entidades.ItemBiblioteca;
import com.luciano.crud.biblioteca.servicos.ServicoException;
import com.luciano.crud.biblioteca.servicos.ItemBibliotecaServico;

@ViewScoped
@ManagedBean
public class ItemBibliotecaDelete extends AbstractBean {

    private static final long serialVersionUID = 4804260264032468336L;

    private ItemBiblioteca item;

    private ItemBibliotecaServico itemServico = new ItemBibliotecaServico();

    public String delete() {
        try {
            itemServico.delete(item);
        } catch (ServicoException e) {
            reportarMensagemDeErro(e.getMessage());
            return null;
        }

        reportarMensagemDeSucesso("Item de biblioteca '" + item.getTitulo() + "' excluído.");

        return "index?faces-redirect=true";
    }

    public String cancel() {
        return "index?faces-redirect=true";
    }

    public ItemBiblioteca getItemBiblioteca() {
        return item;
    }

    public void setItemBiblioteca(ItemBiblioteca item) {
        this.item = item;
    }
}
