
package com.luciano.crud.biblioteca.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.luciano.crud.biblioteca.entidades.Tipo;
import com.luciano.crud.biblioteca.entidades.ItemBiblioteca;
import com.luciano.crud.biblioteca.servicos.ServicoException;
import com.luciano.crud.biblioteca.servicos.ItemBibliotecaServico;

@ViewScoped
@ManagedBean
public class ItemBibliotecaEdit extends AbstractBean {

    private static final long serialVersionUID = -7779155604704232174L;

    private ItemBiblioteca item;

    private ItemBibliotecaServico itemServico = new ItemBibliotecaServico();

    public void init() {
        if (item == null) {
            item = new ItemBiblioteca();
        }
    }

    public String saveItem() {      
        try {
            if (isEdicaoDoItem()) {
                itemServico.update(item);
            } else {
                itemServico.save(item);
            }
        } catch (ServicoException e) {
            reportarMensagemDeErro(e.getMessage());
            return null;
        }

        reportarMensagemDeSucesso("Item de biblioteca '" + item.getTitulo() + "' salvo.");

        return "index.xhtml?faces-redirect=true";
    }

    public boolean isEdicaoDoItem() {
        return item.getId() != null;
    }

    public boolean isLivro() {
        return item != null && item.getTipo() == Tipo.LIVRO;
    }

    public void setItemBiblioteca(ItemBiblioteca item) {
        this.item = item;
    }

    public ItemBiblioteca getItemBiblioteca() {
        return item;
    }

}
