package com.luciano.crud.biblioteca.entidades;

import java.util.Date;

/**
 *
 * @author Luciano Azevedo
 */
public class ItemBiblioteca {

    private Integer id;
    private Tipo tipo;
    private String titulo;
    private String editora;
    private Date dataPublicacao;
    private String descricao;
    private String isbn;
    private Integer paginas;
    private String assunto;
    private String tags;

    public ItemBiblioteca() {
    }

    public ItemBiblioteca(Tipo tipo, String titulo, String editora, Date dataPublicacao, String descricao, String isbn, Integer paginas, String assunto, String tags) {
        
        this.tipo = tipo;
        this.titulo = titulo;
        this.editora = editora;
        this.dataPublicacao = dataPublicacao;
        this.descricao = descricao;
        this.isbn = isbn;
        this.paginas = paginas;
        this.assunto = assunto;
        this.tags = tags;
    }

    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public Date getDataPublicacao() {
        return dataPublicacao;
    }

    public void setDataPublicacao(Date dataPublicacao) {
        this.dataPublicacao = dataPublicacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Integer getPaginas() {
        return paginas;
    }

    public void setPaginas(Integer paginas) {
        this.paginas = paginas;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    @Override
    public String toString() {
        return "ItemBiblioteca [id=" + id + ", tipo=" + tipo + ", titulo=" + titulo + ", editora=" + editora + ", dataPublicacao=" + dataPublicacao + ", descricao=" + descricao + ", isbn=" + isbn + ", paginas=" + paginas + ", assunto=" + assunto + ", tags=" + tags + ']';
    }

}
