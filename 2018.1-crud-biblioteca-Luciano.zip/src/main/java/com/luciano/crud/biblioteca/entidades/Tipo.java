
package com.luciano.crud.biblioteca.entidades;

/**
 *
 * @author Luciano Azevedo
 */
public enum Tipo {
    LIVRO("Livro"), LIVRODEBOLSO("Livro de bolso"), CAPADURA("Capa dura"),
    EBOOK("Ebook"), REVISTA("Revista"), PERIODICO("Periódico");

    private String tipo;
    
    private Tipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getTipo(){
        return this.tipo;
    }
    
    
}
