package com.luciano.crud.biblioteca.filtros;

import java.util.Date;

import com.luciano.crud.biblioteca.entidades.Tipo;

public class ItemFiltro {

    private Tipo tipo;
    private String titulo;
    private String editora;
    private Date dataPublicacaoInical;
    private Date dataPublicacaoFinal;
    private String isbn;
    private Integer paginasInicial;
    private Integer paginasFinal;


    public ItemFiltro() {

    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public Date getDataPublicacaoInical() {
        return dataPublicacaoInical;
    }

    public void setDataPublicacaoInical(Date dataPublicacaoInical) {
        this.dataPublicacaoInical = dataPublicacaoInical;
    }

    public Date getDataPublicacaoFinal() {
        return dataPublicacaoFinal;
    }

    public void setDataPublicacaoFinal(Date dataPublicacaoFinal) {
        this.dataPublicacaoFinal = dataPublicacaoFinal;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Integer getPaginasInicial() {
        return paginasInicial;
    }

    public void setPaginasInicial(Integer paginasInicial) {
        this.paginasInicial = paginasInicial;
    }

    public Integer getPaginasFinal() {
        return paginasFinal;
    }

    public void setPaginasFinal(Integer paginasFinal) {
        this.paginasFinal = paginasFinal;
    }

    public boolean isEmpty() {
		if (this.tipo != null) {
			return false;
		}
    		if (this.titulo != null && !this.titulo.trim().isEmpty()) {
			return false;
		}
		if (this.editora != null && !this.editora.trim().isEmpty()) {
			return false;
		}
		if (this.dataPublicacaoInical != null) {
			return false;
		}
		if (this.dataPublicacaoFinal != null) {
			return false;
		}
		if (this.isbn != null && !this.isbn.trim().isEmpty()) {
			return false;
		}
		if (this.paginasInicial != null) {
			return false;
		}
		if (this.paginasFinal != null) {
			return false;
		}
    		
		return true;
	}

    @Override
    public String toString() {
        return "ItemFiltro[" + "tipo=" + tipo + ", titulo=" + titulo + ", editora=" + editora + ", dataPublicacaoInical=" + dataPublicacaoInical + ", dataPublicacaoFinal=" + dataPublicacaoFinal + ", isbn=" + isbn + ", paginasInicial=" + paginasInicial + ", paginasFinal=" + paginasFinal + ']';
    }
  

}
