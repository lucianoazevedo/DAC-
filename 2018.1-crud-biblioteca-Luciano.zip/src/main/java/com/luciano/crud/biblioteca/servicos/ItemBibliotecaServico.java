package com.luciano.crud.biblioteca.servicos;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.luciano.crud.biblioteca.DAO.PersistenciaException;
import com.luciano.crud.biblioteca.DAO.ItemBibliotecaDAO;
import com.luciano.crud.biblioteca.entidades.ItemBiblioteca;
import com.luciano.crud.biblioteca.filtros.ItemFiltro;

public class ItemBibliotecaServico implements Serializable {

    private static final long serialVersionUID = -7803325791425670859L;

    private ItemBibliotecaDAO itemDAO = new ItemBibliotecaDAO();

    public void save(ItemBiblioteca item) throws ServicoException {
        try {
            // Verificar se ISDN já existe
            validarIsdn(item);
            itemDAO.save(item);
        } catch (PersistenciaException e) {
            throw new ServicoException(e.getMessage(), e);
        }
    }

    public void update(ItemBiblioteca item) throws ServicoException {

        try {
            // Verificar se ISDN já existe
            validarIsdn(item);
            itemDAO.update(item);
        } catch (PersistenciaException e) {
            throw new ServicoException(e.getMessage(), e);
        }
    }

    public void delete(ItemBiblioteca item) throws ServicoException {
        try {
            itemDAO.delete(item);
        } catch (PersistenciaException e) {
            throw new ServicoException(e.getMessage(), e);
        }
    }

    public ItemBiblioteca getByID(int itemId) throws ServicoException {
        try {
            return itemDAO.getByID(itemId);
        } catch (PersistenciaException e) {
            throw new ServicoException(e.getMessage(), e);
        }
    }

    public List<ItemBiblioteca> getAll() throws ServicoException {
        try {
            return itemDAO.getAll();
        } catch (PersistenciaException e) {
            throw new ServicoException(e.getMessage(), e);
        }
    }

    public List<ItemBiblioteca> findBy(ItemFiltro filtro) throws ServicoException {
        try {
            return itemDAO.findBy(filtro);
        } catch (PersistenciaException e) {
            throw new ServicoException(e.getMessage(), e);
        }
    }

    private void validarIsdn(ItemBiblioteca item) throws ServicoException {
        boolean jahExiste = itemDAO.existeIsdn(item);
        if (jahExiste) {
            throw new ServicoException("ISDN já cadastrado: " + item.getIsbn());
        }
    }

    public void povoar(){
        itemDAO.povoar();
    }
}
