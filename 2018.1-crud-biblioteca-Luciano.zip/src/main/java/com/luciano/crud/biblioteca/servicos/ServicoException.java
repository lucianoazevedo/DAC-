package com.luciano.crud.biblioteca.servicos;


public class ServicoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3082351960302866350L;

	public ServicoException(String mensagem) {
		super(mensagem);
	}

	public ServicoException(String mensagem, Throwable causa) {
		super(mensagem, causa);
	}

}
